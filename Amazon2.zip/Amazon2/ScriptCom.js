document.getElementById('btn-iniciar-sesion').addEventListener('click', () => {
    window.location.href = 'IndexLog.html'; //Ruta de acceso del Archivo
});
document.getElementById('btn-vender').addEventListener('click', () =>{
    window.location.href = 'IndexVen.html';
})